---
name: pageindex-search
description: Use PageIndex for vectorless RAG search on user-provided documents via `uv` scripts. Trigger when the user asks to parse/query a PDF or Markdown file, search an existing `*_structure.json`, run one-shot document Q&A with node citations, or open an interactive search REPL over a provided document index.
---

# PageIndex Search

Run end-to-end vectorless document search from a provided path.

## Primary Workflow

Use this command first:

```bash
uv run .claude/skills/pageindex-search/scripts/pageindex_search.py <document-path> "<question>"
```

Supported inputs:
- `.pdf`: build PageIndex structure then query.
- `.md` / `.markdown`: build structure then query.
- `*_structure.json`: query existing structure directly.

The script prints retrieved node IDs/titles/page ranges and a synthesized answer with citations.

## Common Commands

```bash
# Retrieval only (skip final answer synthesis)
uv run .claude/skills/pageindex-search/scripts/pageindex_search.py <document-path> "<question>" --no-answer

# Build/resolve index only
uv run .claude/skills/pageindex-search/scripts/pageindex_search.py <document-path> --index-only

# Open interactive REPL after building/resolving index
uv run .claude/skills/pageindex-search/scripts/pageindex_search.py <document-path>
```

## Options

- `--retrieve-model`: model for indexing/retrieval (default `gpt-4o-mini`)
- `--answer-model`: model for answer synthesis (default `gpt-4o-mini`)
- `--top-k`: max retrieved nodes passed to final answer prompt (default `5`)
- `--api-key`: explicit API key; otherwise use `CHATGPT_API_KEY` or `OPENAI_API_KEY`

## Preflight Checks

1. Confirm `uv` is available and run from repo root.
2. Confirm `CHATGPT_API_KEY` or `OPENAI_API_KEY` is set for model calls.
3. If indexing from file, confirm the input path exists.

## Fallback Tools

When you need raw retrieval evaluation metrics:

```bash
uv run eval_repl.py <path/to/index.json> --bench tests/bench_template.json
```

Use benchmark mode for precision/recall checks; use `pageindex_search.py` for one-shot vectorless RAG on provided documents.
